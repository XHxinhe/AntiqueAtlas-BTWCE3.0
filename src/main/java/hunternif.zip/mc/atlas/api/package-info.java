@API(apiVersion="5.1", owner="antiqueatlas", provides="antiqueatlasapi")
package hunternif.mc.atlas.api;
import cpw.mods.fml.common.API;