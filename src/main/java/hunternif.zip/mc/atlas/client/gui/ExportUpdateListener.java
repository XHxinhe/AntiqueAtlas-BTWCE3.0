package hunternif.mc.atlas.client.gui;

public interface ExportUpdateListener {
	void update(float percentage);
	void setStatusString(String status);
}
